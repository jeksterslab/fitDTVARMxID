library(testthat)
library(fitDTVARMxID)

test_check("fitDTVARMxID")
