# fitDTVARMxID 0.0.0.9002

* Added robust sampling variance-covariance matrix.

# fitDTVARMxID 0.0.0.9001

* Edits to methods.

# fitDTVARMxID 0.0.0.9000