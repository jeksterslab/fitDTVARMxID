library(testthat)
library(OpenMx)
library(fitDTVARMxID)

test_check("fitDTVARMxID")
