# fitDTVARMxID 0.0.0.9004

* Added centered parameterization.

# fitDTVARMxID 0.0.0.9003

* Methods can now return non-converged cases.

# fitDTVARMxID 0.0.0.9002

* Added robust sampling variance-covariance matrix.

# fitDTVARMxID 0.0.0.9001

* Edits to methods.

# fitDTVARMxID 0.0.0.9000